#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <stack>
#include <cstring>
#include <sstream>
#include <iostream>
#include <algorithm>
#include "Element.h"
using namespace std;

class Wad {
    unordered_map<string,Element*> tree;
    //vector<Element> tree;
    fstream wadFile;
    fstream copyOfWadFile;
    uint32_t numberOfDescriptors = 0;
    uint32_t descriptorOffset = 0;
    //char *magic;
    string magic = "";
    string wadPath = "";
    //string blah = "just to run make";
    public:
    Wad(const string &path);
    //~Wad();
    static Wad* loadWad(const string &path);
    string getMagic();
    bool isContent(const string &path);
    bool isDirectory(const string &path);
    int getSize(const string &path);
    int getContents(const string &path, char *buffer, int length, int offset = 0);
    int getDirectory(const string &path, vector<string> *directory);
    void createDirectory(const string &path);
    void createFile(const string &path);
    int writeToFile(const string &path, const char *buffer, int length, int offset = 0);
};