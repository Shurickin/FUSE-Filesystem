#include <cstdint>
#include <string>
#include <vector>
using namespace std;
class Element{
    uint32_t offset;
    uint32_t length;
    string name;
    vector<Element*> children;
    public:
    Element(){}
    Element(uint32_t off, uint32_t len, string name){
        offset = off;
        length = len;
        this->name = name;
    }
    ~Element() {
        for (Element* child : children) {
            if (child != nullptr) {
                delete child; // Delete element recursively
            }
        }
    }
    void addElement(Element *elem){
        children.push_back(elem);
    }
    vector<Element*> getChildren(){return children;}
    string getName() {return name;}
    void changeName(string newName) {name = newName;}
    uint32_t getLength() {return length;}
    void setLength(uint32_t leng) {length = leng;}
    uint32_t getOffset() {return offset;}
    void setOffset(uint32_t off) {offset = off;}
};