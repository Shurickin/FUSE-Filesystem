#include "Wad.h"

Wad::Wad(const string &path){
    wadFile.open(path, ios::in | ios::out | ios::binary);
    wadPath = path;
    // wadFile.open("../test-workspace/testfiles/sample1.wad", ios::in | ios::out | ios::binary);
    //root = new Element(0,0,"/");
    Element *root = new Element(0,0,"/");
    //tree.push_back(root);
    tree["/"] = root;

    char magic[5];
    magic[4] = '\0';
    uint32_t numberOfDescriptors;
    uint32_t descriptorOffset;

    wadFile.read(magic, 4);
    wadFile.read((char*)&numberOfDescriptors, 4);
    wadFile.read((char*)&descriptorOffset, 4);

    this->numberOfDescriptors = numberOfDescriptors;
    this->descriptorOffset = descriptorOffset;
    this->magic = magic;
    // cout << "The Magic is: " << this->magic << endl;
    // cout << "The number of Descriptors is: " << this->numberOfDescriptors << endl;
    // cout << "The Descriptor Offset is: " << this->descriptorOffset << endl;
    wadFile.seekg(descriptorOffset); // goes to descriptor offset

    //stack<string> stack;
    vector<string> starts;
    int dirLevel = 0;
    //stack.push("/");
    starts.push_back("/");
    bool first = true;
    bool endOfFile = false;
    bool firstStart = true;
    int count = 0;
    while(count < numberOfDescriptors){
        //cout << "in the loop\n";
        // read the next 16 bytes
        uint32_t offset;
        uint32_t length;
        char name[9];
        name[8] = '\0';
        wadFile.read((char*)&offset, 4);
        //cout << "Offset: " << offset << endl;
        wadFile.read((char*)&length, 4);
        //cout << "Length: " << length << endl;
        wadFile.read(name, 8);
        //cout << "Name: " << name << endl;

        // make the element
        Element *elem = new Element(offset, length, name);
        //stack.push(name);

        //cout << "made element and pushed on stack\n";
        //cout << "Length: " << length << endl;
        string stringName = name;
        bool pattern = false;
        for (int i = 0; i < stringName.length(); i++) {
            //cout << "in pattern loop\n";
            // Check if the current substring matches the pattern "E#M#"
            if (name[i] == 'E' && name[i + 2] == 'M' && 
                name[i + 1] >= '0' && name[i + 1] <= '9' &&
                name[i + 3] >= '0' && name[i + 3] <= '9') {
                //cout << "pattern found true\n" ;   
                pattern = true; // Pattern found
                break;
            }
        }
        bool used = false;
        bool end = false;
        // see what the element is
        if(strstr(name, "_START") != nullptr){ // if its the start of a directory
            stringName = stringName.substr(0,2);
            elem->changeName(stringName);
            starts.push_back(name);
            tree[name] = elem;
            if(firstStart){
                tree["/"]->addElement(elem);
                firstStart = false;
            }
            else{
                tree[starts[starts.size() - 2]]->addElement(elem);
            }
            used = true;
            // dirLevel++; // in a new directory
            // used = true;
        }
        else if (pattern == true){
            //cout << "inside the E#M#\n";
            // read 10 descriptors
            for(int i = 0; i < 10; i++){
                // read the next 16 bytes
                uint32_t elemOffset;
                uint32_t elemLength;
                char elemName[9];
                elemName[8] = '\0';
                wadFile.read((char*)&elemOffset, 4);
                wadFile.read((char*)&elemLength, 4);
                wadFile.read(elemName, 8);
                //cout << i << "Element ---- " << elemLength << endl;
                // cout << "Elem Length: " << elemLength << endl;
                // cout << "Elem offset: " << elemOffset << endl;
                // cout << "Elem name: " << elemName << endl;

                // make the element
                Element *element = new Element(elemOffset, elemLength, elemName);
                elem->addElement(element);
                count++;
            }
            //stack.pop();
        }
        else if (strstr(name, "_END") != nullptr){
            // dirLevel--;
            end = true;
            // string stringName = name;
            // string trueName = stringName.substr(0,stringName.length() - 4);

            //stack.pop();
            starts.pop_back();
        }
        // if (used == false && end == false){
        //     Element &directory = tree[dirLevel]; // the directory we are in
        //     directory.addElement(elem);
        // }

        if(first){
            tree.at("/")->addElement(elem);
            first = false;
        }
        else {
            if(end != true && used == false){
                // use the latest start
                auto it = tree.find(starts.back());
                if (it != tree.end()) {
                    it->second->addElement(elem);
                }
                end = false;
                used = false;
            }
        }

        // endOfFile = wadFile.eof();
        // std::cout << "The value of endOfFile is: " << endOfFile << std::endl;
        // if (endOfFile) {
        //     break; // Exit the loop if end of file is reached
        // }
        count++;
    }
    wadFile.close();

    // for(auto child : tree.at("/")->getChildren()){
    //     cout << child->getName() << endl;
    // }

    // for(auto pair : tree){
    //     cout << "Parent name: " << pair.second->getName() << endl;
    //     for(auto child : pair.second->getChildren()){
    //         cout << child->getName() << endl;
    //     }
    // }
    
}

// Wad::~Wad(){
//     for (auto& pair : tree) {
//         if (pair.second != nullptr) {
//             delete pair.second; // Delete element recursively
//         }
//     }
//     for (auto itr = tree.begin(); itr != tree.end(); /* no increment here! */)
//     {
//         if(itr->second != nullptr){
//             delete itr->second;
//         }
//         itr = tree.erase(itr);
//     }
// }

Wad* Wad::loadWad(const string &path){
    Wad *wad = new Wad(path);
    return wad;
}

string Wad::getMagic(){
    return magic;
}

bool findPath(vector<string> names, vector<Element*> children) {
    bool content = false;
    // Base case: if the node is null, return
    if (names.size() == 0 || children.size() == 0) {
        return true;
    }
    
    // Recursively print keys of all children nodes
    for (Element* child : children) {
        //cout << child->getName() << endl;
        if(strcmp(child->getName().c_str(), names[0].c_str()) == 0){
            names.erase(names.begin());
            content = findPath(names, child->getChildren());
            break;
        }
    }
    return content;
}

Element* findPath2(vector<string> names, vector<Element*> children, Element *elem) {
    //Element *elem = new Element(0,0,"");
    bool content = false;
    // Base case: if the node is null, return
    if (names.size() == 0 || children.size() == 0) {
        return nullptr;
    }
    
    // Recursively print keys of all children nodes
    for (Element* child : children) {
        //cout << child->getName() << endl;
        if(strcmp(child->getName().c_str(), names[0].c_str()) == 0){
            string name = names[names.size()-1];
            names.erase(names.begin());
            elem = findPath2(names, child->getChildren(), elem);
            // cout << "Name in findPath2: " << name << endl;
            // cout << "Elem Name in findPath2: " << child->getName() << endl;
            // cout << "Number of Children: " << child->getChildren().size() << endl;
            // if (child->getChildren().size() > 0){
            //     cout << "Child's Name: " << child->getChildren().at(0)->getName() << endl;
            // }
            if(elem == nullptr){
                //cout << "Elem equals the child\n";
                elem = child;
            }
            break;
        }
    }
    return elem;
}

bool Wad::isContent(const string &path){
    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    if(path == "/" || path == ""){ // this is a root directory or nothing
        return false;
    }

    // cout << "Path name:\n";
    // for(string thing : names){
    //     cout << "Name of path: " << thing << endl;
    // }
    // cout << "Tree names:\n";
    // for (auto it = tree.begin(); it != tree.end(); ++it) {
    //     std::cout << it->first << "\n";
    //     cout << "Kid names:\n";
    //     for(auto thing : it->second->getChildren()){
    //         cout << thing->getName() << endl;
    //     }
    // }

    bool content = findPath(names, tree.at("/")->getChildren());
    Element *elem = nullptr;
    elem = findPath2(names, tree.at("/")->getChildren(), elem);
    //elem = getElemAtPath2(names, tree, elem);
    if(elem != nullptr){
        //cout << "Element Found: " << elem->getName() << endl;
        if (elem->getLength() == -1){ //  new file
            return true;
        }
        else if(elem->getLength() < 1){
            return false;
        }
    }
    else{
        //cout << "Element is NULLPTR\n";
    }
    return content;
}

bool Wad::isDirectory(const string &path){
    bool content = isContent(path);
    if(content){
        return false;
    }

    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    if(path == "/"){ // this is a root directory
        return true;
    }
    else if(path == ""){
        return false;
    }

    // for(string nm : names){
    //     cout << "Name: " << nm << endl;
    // }

    content = findPath(names, tree.at("/")->getChildren());
    Element *elem = nullptr;
    elem = findPath2(names, tree.at("/")->getChildren(), elem);
    //elem = getElemAtPath2(names, tree, elem);
    if(elem != nullptr){
        //cout << "Element Found: " << elem->getName() << endl;
        if(strcmp(elem->getName().c_str(), names[names.size() - 1].c_str()) != 0){
            return false;
        }
        else if (elem->getLength() == -1){ //  new file
            return false;
        }
        else if(elem->getLength() < 1){
            return true;
        }
    }
    else{
        //cout << "Element is NULLPTR\n";
    }
    return content;
}

int Wad::getSize(const string &path){
    bool content = isContent(path);
    if(content == true){
        vector<std::string> names;
        istringstream iss(path);
        string name;
        while (getline(iss, name, '/')) {
            if (!name.empty()) {
                names.push_back(name);
            }
        }
        Element *elem = nullptr;
        elem = findPath2(names, tree.at("/")->getChildren(), elem);
        return elem->getLength();
    }
    else{
        return -1;
    }
}

int Wad::getContents(const string &path, char *buffer, int length, int offset){
    bool content = isContent(path);
    if(content == false){
        return -1;
    }

    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    Element *elem = nullptr;
    elem = findPath2(names, tree.at("/")->getChildren(), elem);
    wadFile.open(wadPath);
    wadFile.seekg(elem->getOffset() + offset); // goes to offset

    //cout << "Elem Length: " << elem->getLength() << endl;
    //cout << "Length wanted: " << length << endl;

    if(offset >= elem->getLength()){
        return 0;
    }

    if(elem->getLength() - offset < length){ // read what we can
        //wadFile.read(buffer, length);
        if(elem->getLength() - offset < 0){
            return 0;
        }
        wadFile.read(buffer, elem->getLength() - offset);
        wadFile.close();
        return elem->getLength() - offset;
    }
    else{ // we can read everything
        wadFile.read(buffer, length);
        wadFile.close();
        return length;
    }
    //wadFile.read(buffer, length);
    
}

int Wad::getDirectory(const string &path, vector<string> *directory){
    bool dir = isDirectory(path);
    if(dir == false){
        return -1;
    }

    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    Element *elem = nullptr;
    if(path == "/"){
        elem = tree.at("/");
    }
    else{
        elem = findPath2(names, tree.at("/")->getChildren(), elem);
    }

    // if(elem != nullptr){
    //     // cout << "Elem Name in getDirectory: " << elem->getName() << endl;
    //     // cout << "Elem's children size in getDirectory: " << elem->getChildren().size() << endl;
    // }
    

    for(auto child : elem->getChildren()){
        directory->push_back(child->getName());
    }
    return directory->size();
}

void copyFrom(fstream& inputFile, fstream& outputFile, int startPosition) {
    char buffer[256]; // Buffer for reading data (adjust size as needed)

    // Seek to the start position in the input file
    inputFile.seekg(startPosition, std::ios::beg);
    std::streampos position = inputFile.tellg();
    //std::cout << "Current position: " << position << std::endl;

    if (inputFile.eof()) {
        std::cerr << "Error: End of file reached!" << std::endl;
        return; // Exit the function
    }
    // inputFile.read(buffer, 8);
    // cout << "Buffer contents: " << buffer << endl;

    //cout << "in CopyFrom before the loop\n";

    // Copy data from input file to output file until end of file
    while (true) {
        //cout << "in CopyFrom\n";
        inputFile.read(buffer, sizeof(buffer));
        std::streamsize bytesRead = inputFile.gcount();
        if (bytesRead > 0) {
            outputFile.write(buffer, bytesRead);
        }
        else{
            break;
        }
    }
}

void copyUpTo(fstream& inputFile, fstream& outputFile, int numBytes) {
    inputFile.seekg(0, std::ios_base::end);
    // Get the position, which represents the size of the file
    std::streampos fileSize = inputFile.tellg();
    // cout << "File Size: " << fileSize << endl;
    int size = fileSize;
    // cout << "Size: " << size << endl;
    inputFile.seekg(0, std::ios_base::beg);
    if(size < numBytes){
        // cout << "In size < numBytes!\n";
        char buffer[size]; // Buffer for reading data (adjust size as needed)
        inputFile.read(buffer, size);
        std::streamsize bytesRead = inputFile.gcount();
        // cout << "Bytes Read: " << bytesRead << endl;
        // cout << "Buffer in copyUpTo: " << buffer << endl;
        // cout << "Count in copyUpTo: " << numBytes << endl;
        outputFile.write(buffer, size);
    }
    else{
         char buffer[numBytes]; // Buffer for reading data (adjust size as needed)
        inputFile.read(buffer, numBytes);
        std::streamsize bytesRead = inputFile.gcount();
        // cout << "Bytes Read: " << bytesRead << endl;
        // cout << "Buffer in copyUpTo: " << buffer << endl;
        // cout << "Count in copyUpTo: " << numBytes << endl;
        outputFile.write(buffer, numBytes);
    }
    // Copy data from input file to output file until specified number of bytes
    // int bytesCopied = 0;
    // while (bytesCopied < numBytes && !inputFile.eof()) {
    //     int bytesToRead = std::min(static_cast<int>(sizeof(buffer)), numBytes - bytesCopied);
    //     inputFile.read(buffer, bytesToRead);
    //     std::streamsize bytesRead = inputFile.gcount();
    //     if (bytesRead > 0) {
    //         outputFile.write(buffer, bytesRead);
    //         bytesCopied += bytesRead;
    //     }
    // }
}

void Wad::createDirectory(const string &path){
    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    vector<string> copyOfNames = names;
    copyOfNames.pop_back();
    string copyOfPath = "";
    for(string copy : copyOfNames){
        copyOfPath += copy;
    }
    //cout << "Copy of the path: " << copyOfPath << endl;
    bool dir = isDirectory(copyOfPath);
    if(dir == false && path == ""){
        //cout << "Directory path is wrong!\n";
        return;
    }
    else if (names[names.size() - 1].length() > 2){
        //cout << "Name is too long!\n";
        return;
    }

    if(names.size() == 1){ // in the root directory
        if(names.at(0).length() > 2){
            //cout << "cannot create directory\n";
            return;
        }
        //cout << "Element Name: " << names[0] << endl;
        Element *elem = new Element(0,0,names[0]);
        tree.at("/")->addElement(elem);

        // update the wadfile
        std::ofstream outputFile;
        outputFile.open(wadPath, std::ios::in | std::ios::out | std::ios::binary); // Open file in append mode
        outputFile.seekp(0, std::ios::end); // Seek to the end of the file

        if (!outputFile) {
            std::cerr << "Error opening file!" << std::endl;
            return;
        }

        // Write content to the end of the file
        uint32_t length = 0;
        uint32_t offset = 0;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        outputFile.write(reinterpret_cast<const char*>(&length), sizeof(uint32_t));
        outputFile << names[0] << "_START";
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        outputFile.write(reinterpret_cast<const char*>(&length), sizeof(uint32_t));
        //outputFile << names[0] << "_END";
        string tmp = names[0] + "_END";
        outputFile.write(tmp.data(), 8);

        // change descriptor number
        //cout << "In Root (CD) Before Changing Number of Descriptors: " << numberOfDescriptors << endl;
        outputFile.seekp(4, std::ios::beg);
        numberOfDescriptors += 2;
        offset = numberOfDescriptors;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        //cout << "In Root (CD) After Changing Number of Descriptors: " << numberOfDescriptors << endl;

        // Close the file
        outputFile.flush();
        outputFile.close();

        //cout << "Wrote everything!\n";

        //wadFile.close();
    }
    else{ // its not the root directory
        Element *elem = nullptr;
        Element *directory = new Element(0,0,names[names.size()-1]);
        elem = findPath2(copyOfNames, tree.at("/")->getChildren(), elem);
        if(elem == nullptr){
            //cout << "Something wrong with path!\n";
            return;
        }
        elem->addElement(directory);

        name = elem->getName() + "_END";
        //cout << "Name we want: " << name << endl;

        vector<string> starts;
        wadFile.open(wadPath);
        wadFile.seekg(descriptorOffset);
        char buffer[16];
        int count = descriptorOffset;
        while(wadFile.read(buffer, 16)){
            char NAME[8];
            for(int i = 0; i<8; i++){
                NAME[i] = buffer[i + 8];
            }

            if(strstr(NAME, "_START") != nullptr){
                string tmp = NAME;
                tmp = tmp.substr(0,2);
                starts.push_back(tmp);
            }
            else if(strstr(NAME, "_END") != nullptr){
                starts.pop_back();
            }

            //cout << "NAME: " << NAME << endl;
            
            if(strcmp(name.c_str(), NAME) == 0){
                string myPath = "/";
                for(string stuff : starts){
                    myPath += stuff + "/";
                }
                myPath = myPath.substr(0, myPath.length() - 1);
                if(strstr(path.c_str(), myPath.c_str()) != nullptr){
                    break;
                }
                // cout << "This while loop is broken!\n";
                // cout << "This is the name: " << NAME << endl;
                //count -= 8; // move on to the next descriptor start
                //break;
            }
            count += 16;
        }
        //cout << "Count: " << count << endl;
        // wadFile.close();


        // update the wadfile
        fstream outputFile;
        outputFile.open(wadPath + ".tmp", std::ios::out | std::ios::binary); // Open file in append mode
        //outputFile.open(wadPath + ".tmp", std::ios::out | std::ios::binary); // Open file in append mode
        //cout << "opened file\n";
        wadFile.close();
        wadFile.open(wadPath);
        
        copyUpTo(wadFile, outputFile, count);

        //outputFile.seekp(count, std::ios::beg); // Seek to ex_END

        // cout << wadPath + ".tmp" << endl;

        // if (!outputFile.is_open()) {
        //     std::cerr << "Error opening file!" << std::endl;
        //     if (outputFile.fail()) {
        //         std::cerr << "Fail bit is set." << std::endl;
        //     }
        //     return;
        // }
        // else{
        //     cout << "Everything works\n";
        // }

        // if (!outputFile) {
        //     cout << "this is the output file\n";
        //     std::cerr << "Error opening file!" << std::endl;
        //     return;
        // }
        // else{
        //     cout << "Everything works\n";
        // }

        // copy the rest of the file in another data structure


        // Write content to the end of the file
        uint32_t length = 0;
        uint32_t offset = 0;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        outputFile.write(reinterpret_cast<const char*>(&length), sizeof(uint32_t));
        //cout << "Name of the start: " << names[names.size() - 1] << endl;
        outputFile << names[names.size() - 1] << "_START";
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        outputFile.write(reinterpret_cast<const char*>(&length), sizeof(uint32_t));
        //outputFile << names[names.size() - 1] << "_END";
        string tmp = names[names.size() - 1] + "_END";
        outputFile.write(tmp.data(), 8);

        // change descriptor number
        //cout << "Not Root (CD) Before Changing Number of Descriptors: " << numberOfDescriptors << endl;
        outputFile.seekp(4, std::ios::beg);
        numberOfDescriptors += 2;
        offset = numberOfDescriptors;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        //cout << "Not Root (CD) After Changing Number of Descriptors: " << numberOfDescriptors << endl;

        // set descriptor offset
        outputFile.write(reinterpret_cast<const char*>(&descriptorOffset), sizeof(uint32_t));

        //Copy the rest
        //cout << "At CopyFrom\n";
        outputFile.seekp(0, std::ios_base::end);
        copyFrom(wadFile, outputFile, count);
        //cout << "Copied everything\n";
        // Close the file
        outputFile.flush();
        outputFile.close();
        wadFile.close();

        // Replace original file with modified file
        std::remove(wadPath.c_str());
        std::rename((wadPath + ".tmp").c_str(), wadPath.c_str());
        
    }
}
void Wad::createFile(const string &path){
    bool content = isContent(path);
    if(content != false){
        return;
    }

    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    vector<string> copyOfNames = names;
    copyOfNames.pop_back();
    string copyOfPath = "";
    for(string copy : copyOfNames){
        copyOfPath += copy;
    }
    //cout << "Copy of the path: " << copyOfPath << endl;
    bool dir = isDirectory(copyOfPath);
    if(dir == false && path == ""){
        //cout << "Directory path is wrong!\n";
        return;
    }
    else if (names[names.size() - 1].length() > 8){
        //cout << "Name is too long!\n";
        return;
    }

    if(names.size() == 1){ // in the root directory

        //cout << "Element Name: " << names[0] << endl;
        string stringName = names[0];
        //cout << "StringName: " << stringName << endl;
        bool pattern = false;
        for (int i = 0; i < stringName.length(); i++) {
            //cout << "in pattern loop\n";
            // Check if the current substring matches the pattern "E#M#"
            if (stringName[i] == 'E' && stringName[i + 2] == 'M' && 
                stringName[i + 1] >= '0' && stringName[i + 1] <= '9' &&
                stringName[i + 3] >= '0' && stringName[i + 3] <= '9') {
                //cout << "pattern found true\n" ;   
                pattern = true; // Pattern found
                break;
            }
        }
        if(pattern){
            //cout << "Inside E#M# directory!\n";
            return;
        }

        Element *elem = new Element(0,-1,names[0]);
        tree.at("/")->addElement(elem);

        // cout << "In createFile:\n";
        // cout << "Elem Found: " << elem->getName() << endl;
        // cout << "Elem Size: " << elem->getLength() << endl;
        // bool isNeg1 = false;
        // cout << "Bool Value: " << isNeg1 << endl;
        

        // update the wadfile
        std::ofstream outputFile;
        outputFile.open(wadPath, std::ios::in | std::ios::out | std::ios::binary); // Open file in append mode
        outputFile.seekp(0, std::ios::end); // Seek to the end of the file

        if (!outputFile) {
            std::cerr << "Error opening file!" << std::endl;
            return;
        }

        // Write content to the end of the file
        uint32_t length = -1;
        uint32_t offset = 0;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        outputFile.write(reinterpret_cast<const char*>(&length), sizeof(uint32_t));
        //outputFile << names[0];
        string tmp = names[0];
        outputFile.write(tmp.data(), 8);

        // change descriptor number
        //cout << "In Root (CF) Before Changing Number of Descriptors: " << numberOfDescriptors << endl;
        outputFile.seekp(4, std::ios::beg);
        numberOfDescriptors++;
        offset = numberOfDescriptors;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        //cout << "In Root (CF) After Changing Number of Descriptors: " << numberOfDescriptors << endl;

        // Close the file
        outputFile.flush();
        outputFile.close();

        //cout << "Wrote everything!\n";
    }
    else{ // its not the root directory
        Element *elem = nullptr;
        Element *directory = new Element(0,-1,names[names.size()-1]);
        elem = findPath2(copyOfNames, tree.at("/")->getChildren(), elem);
        if(elem == nullptr){
            //cout << "Something wrong with path!\n";
            return;
        }
        else {
            string stringName = elem->getName();
            //cout << "StringName: " << stringName << endl;
            bool pattern = false;
            for (int i = 0; i < stringName.length(); i++) {
                //cout << "in pattern loop\n";
                // Check if the current substring matches the pattern "E#M#"
                if (stringName[i] == 'E' && stringName[i + 2] == 'M' && 
                    stringName[i + 1] >= '0' && stringName[i + 1] <= '9' &&
                    stringName[i + 3] >= '0' && stringName[i + 3] <= '9') {
                    //cout << "pattern found true\n" ;   
                    pattern = true; // Pattern found
                    break;
                }
            }
            if(pattern){
                //cout << "Inside E#M# directory!\n";
                return;
            }
        }
        elem->addElement(directory);

        name = elem->getName() + "_END";
        //cout << "Name we want: " << name << endl;

        vector<string> starts;

        wadFile.open(wadPath);
        wadFile.seekg(descriptorOffset);
        char buffer[16];
        int count = descriptorOffset;
        while(wadFile.read(buffer, 16)){
            char NAME[8];
            for(int i = 0; i<8; i++){
                NAME[i] = buffer[i + 8];
            }

            if(strstr(NAME, "_START") != nullptr){
                string tmp = NAME;
                tmp = tmp.substr(0,2);
                starts.push_back(tmp);
            }
            else if(strstr(NAME, "_END") != nullptr){
                starts.pop_back();
            }

            //cout << "NAME: " << NAME << endl;
            
            if(strcmp(name.c_str(), NAME) == 0){
                string myPath = "/";
                for(string stuff : starts){
                    myPath += stuff + "/";
                }
                myPath = myPath.substr(0, myPath.length() - 1);
                if(strstr(path.c_str(), myPath.c_str()) != nullptr){
                    break;
                }
                // cout << "This while loop is broken!\n";
                // cout << "This is the name: " << NAME << endl;
                //count -= 8; // move on to the next descriptor start
                //break;
            }
            count += 16;
        }
        //cout << "Count: " << count << endl;
        // wadFile.close();


        // update the wadfile
        fstream outputFile;
        outputFile.open(wadPath + ".tmp", std::ios::out | std::ios::binary); // Open file in append mode

        wadFile.close();
        wadFile.open(wadPath);
        
        copyUpTo(wadFile, outputFile, count);

        // Write content to the file
        uint32_t length = -1;
        uint32_t offset = 0;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        outputFile.write(reinterpret_cast<const char*>(&length), sizeof(uint32_t));
        //cout << "Name of the start: " << names[names.size() - 1] << endl;
        //outputFile << names[names.size() - 1];
        string tmp = names[names.size() - 1];
        outputFile.write(tmp.data(), 8);

        // change descriptor number
        //cout << "Not In Root (CF) Before Changing Number of Descriptors: " << numberOfDescriptors << endl;
        outputFile.seekp(4, std::ios::beg);
        numberOfDescriptors++;
        offset = numberOfDescriptors;
        outputFile.write(reinterpret_cast<const char*>(&offset), sizeof(uint32_t));
        //cout << "In Root (CF) After Changing Number of Descriptors: " << numberOfDescriptors << endl;

        // set descriptor offset
        outputFile.write(reinterpret_cast<const char*>(&descriptorOffset), sizeof(uint32_t));

        //Copy the rest
        outputFile.seekp(0, std::ios_base::end);
        copyFrom(wadFile, outputFile, count);
        //cout << "Copied everything\n";
        // Close the file
        outputFile.flush();
        outputFile.close();
        wadFile.close();

        // Replace original file with modified file
        std::remove(wadPath.c_str());
        std::rename((wadPath + ".tmp").c_str(), wadPath.c_str());
        
    }
}
int Wad::writeToFile(const string &path, const char *buffer, int length, int offset){
    bool content = isContent(path);
    if(content == false){
        return -1;
    }

    vector<std::string> names;
    istringstream iss(path);
    string name;
    while (getline(iss, name, '/')) {
        if (!name.empty()) {
            names.push_back(name);
        }
    }

    Element *elem = nullptr;
    elem = findPath2(names, tree.at("/")->getChildren(), elem);
    name = elem->getName();

    //cout << "Elem Found: " << elem->getName() << endl;
    //cout << "Elem Size: " << elem->getLength() << endl;

    if(elem->getLength() > 0 && elem->getLength() != -1){ // non-empty file
        return 0;
    }

    string contents = "";
    for(int i = 0; i < length; i++){
        contents += buffer[i];
    }

    wadFile.open(wadPath);
    wadFile.seekg(descriptorOffset, std::ios::beg);
    char buff[16];
    int count = descriptorOffset;
    //cout << "Count before scanning wadFile: " << count << endl;
    while(wadFile.read(buff, 16)){
        char NAME[8];
        for(int i = 0; i<8; i++){
            NAME[i] = buff[i + 8];
        }
        //cout << "NAME: " << NAME << endl;
        
        if(strcmp(name.c_str(), NAME) == 0){
            // cout << "This while loop is broken!\n";
            // cout << "This is the name: " << NAME << endl;
            break;
        }
        count += 16;
    }
    //cout << "Count is: " << count << endl;

    wadFile.close();

    fstream outputFile;
    outputFile.open(wadPath + ".tmp", std::ios::out | std::ios::binary);

    wadFile.open(wadPath);

    copyUpTo(wadFile, outputFile, 12 + offset); // copies header and maybe lump data

    // add new info
    outputFile.write(contents.data(), length);
    elem->setLength(length);
    elem->setOffset(12 + offset);

    copyFrom(wadFile, outputFile, 12 + offset);

    outputFile.seekp(8, std::ios::beg);
    descriptorOffset += length;
    outputFile.write(reinterpret_cast<const char*>(&descriptorOffset), sizeof(uint32_t));

    outputFile.seekp(count + length, std::ios::beg); // should be at the file descriptor
    uint32_t len = length;
    uint32_t off = offset + 12;
    outputFile.write(reinterpret_cast<const char*>(&off), sizeof(uint32_t));
    outputFile.write(reinterpret_cast<const char*>(&len), sizeof(uint32_t));
    
    // Close the file
    outputFile.flush();
    outputFile.close();
    wadFile.close();

    // Replace original file with modified file
    std::remove(wadPath.c_str());
    std::rename((wadPath + ".tmp").c_str(), wadPath.c_str());

    return length;
}