#define FUSE_USE_VERSION 26
#include <sys/stat.h>
#include <linux/stat.h>
#include <fcntl.h>
#include <string.h>
#include <cerrno>
#include <unistd.h>
#include "../libWad/Wad.h"
//#include "fuse.h"
#include <fuse.h>



static int getattr_callback(const char *path, struct stat *stbuf) {

  //std::cerr << "In getattr_callback!" << endl;

  if(((Wad*)fuse_get_context()->private_data)->isDirectory(path)){
    //std::cerr << "Is Directory!" << endl;
    stbuf->st_mode = S_IFDIR | 0755;
    stbuf->st_nlink = 2;
    return 0;
  }

  if(((Wad*)fuse_get_context()->private_data)->isContent(path)){
    std::cerr << "Is Content!" << endl;
    stbuf->st_mode = S_IFREG | 0777;
    stbuf->st_nlink = 1;
    if(((Wad*)fuse_get_context()->private_data)->getSize(path) == -1){
      stbuf->st_size = 0;
    }
    else{
      stbuf->st_size = ((Wad*)fuse_get_context()->private_data)->getSize(path);
    }
    return 0;
  }

  return -ENOENT;
}

static int mknod_callback( const char *path, mode_t mode, dev_t rdev )
{
	//path++;
	// add_file( path );
  std::cerr << "In Mknod_callback!" << endl;
  std::cerr << "Path:" << path << endl;
  ((Wad*)fuse_get_context()->private_data)->createFile(path);
  //int result = mknod(path, mode, rdev);
  // if (result == -1 || ((Wad*)fuse_get_context()->private_data)->isContent(path) == false) {
  //   // Error handling
  //   return -errno; // Propagate the errno value as the error code
  // }
	// if (((Wad*)fuse_get_context()->private_data)->isContent(path) == false) {
  //   std::cerr << "No content after created file!" << endl;
  //   return -errno; // Return the error code encountered during mknod
  // }
  //std::cerr << "Created the file!" << endl;
	return 0;
}

static int mkdir_callback( const char *path, mode_t mode )
{
  std::cerr << "In Mkdir_callback!" << endl;
  std::cerr << "Path: " << path << endl;
  ((Wad*)fuse_get_context()->private_data)->createDirectory(path);
	// if (((Wad*)fuse_get_context()->private_data)->isDirectory(path) == false) {
  //   std::cerr << "Is Not a Directory!" << endl;
  //   return -errno; // Return the error code encountered during mkdir
  // }
	return 0;
}

static int read_callback(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi) {
  std::cerr << "In read_callback!" << endl;

  if (((Wad*)fuse_get_context()->private_data)->isContent(path)) {
    auto filecontent = ((Wad*)fuse_get_context()->private_data)->getContents(path, buf, size, offset);
    return filecontent;
  }

  // int filecontent = ((Wad*)fuse_get_context()->private_data)->getContents(path, buf, size, offset);
  // if(filecontent < 0){
  //   return -ENOENT;
  // }

  return -ENOENT;
}

static int write_callback2( const char *path, const char *buffer, size_t size, off_t offset, struct fuse_file_info *info )
{
	//write_to_file( path, buffer );
  std::cerr << "In Write_callback!" << endl;
  int count = ((Wad*)fuse_get_context()->private_data)->writeToFile(path, buffer, size, offset);
	if(count == -1 || count == 0){
    return -errno;
  }
  // if(count == 0){
  //   return -errno;
  // }
	return count;
}

static int readdir_callback(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
  (void) offset;
  (void) fi;
  std::cerr << "I'm in readdir!\n";
  if(((Wad*)fuse_get_context()->private_data)->isDirectory(path)){
    //std::cout << "This is a directory" << endl;

    filler(buf, ".", NULL, 0);
    filler(buf, "..", NULL, 0);

    vector<string> directories;
    int count = ((Wad*)fuse_get_context()->private_data)->getDirectory(path, &directories);

    for (const string dir : directories){
      filler(buf, dir.c_str(), NULL, 0);
    }
    return 0;
  }

  // filler(buf, filename, NULL, 0);

  return -errno;
}

// static int open_callback(const char *path, struct fuse_file_info *fi){
//   return 0;
// }

static struct fuse_operations fuse_example_operations = {
  .getattr = getattr_callback,
  .mknod = mknod_callback,
  .mkdir = mkdir_callback,
  //.open = open_callback,
  .read = read_callback,
  .write = write_callback2,
  .readdir = readdir_callback,
};

int main(int argc, char *argv[]) {
  if (argc < 3) {
    std::cout << "Not enough arguments." << std::endl;
    exit(EXIT_SUCCESS);
  }

  std:: string wadPath = argv[argc - 2];

  if(wadPath.at(0) != '/'){
    wadPath = std::string(get_current_dir_name()) + "/" + wadPath;
  }

  std::cout << "WadPath: " << wadPath << endl;

  Wad *myWad = Wad::loadWad(wadPath);

  argv[argc-2] = argv[argc - 1];
  argc--;

  //fuse_get_context()->private_data
  return fuse_main(argc, argv, &fuse_example_operations, myWad);
}